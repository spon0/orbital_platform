# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from typing import Literal

from .. import FunctionCall, FunctionRef

class ClipTile(FunctionCall, frozen=True):
    """
    Function to clip a raster tile along the lines of a vector tile.

    Args:
        tile: FunctionRef for raster TileData that gets clipped.
        vector_tile: FunctionRef for vector TileData (polygons) along which to clip.
        crop_inside: If True, clip returns the raster inside the polygons. If False, clip
                     returns the raster outside the polygons.

    Function Returns:
        TileData with the clipped raster tile information.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.ClipTile'] =\
                        'dfm.api.maptiling_2d.ClipTile'
    tile: FunctionRef
    vector_tile: FunctionRef
    crop_inside: bool = True
