# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from typing import Literal

from .. import FunctionCall, FunctionRef

class BlendRasterTiles(FunctionCall, frozen=True):
    """Function to blend two raster tiles. BlendRasterTile 
    supports different blend modesl.
    
    * When set to 'both', it computes clip(src1∗alpha+src2∗beta+gamma). That is, both transparency
      channels are effectively combined and the result is transparent where any of its inputs
      is transparent.
    * When set to 'addto_src1', it computes clip(src1*alpha + src2.filled(0)*beta + gamma). That is,
      only the transparency of src1 is kept. src2's transparency is set to 0, effectively keeping
      the original src1 values. Where src2 is not transparent, however, the values of src1 and src2
      are added.
    * Same for 'addto_src2', just the other way around.
    * When set to 'into_src1', it conputes clip(np.copyto(src1*alpha, src2.filled(0)*beta, where=src2*beta != 0) + gamma).
      That is, similar to addto_src1 the transparency is only kept from src1. However, where
      src2 is not transparent, instead of adding src1 and src2, into_src1 copies the src2 values
      into src1, overwriting src1.
    * Same for 'into_src2', just the other way around.

    Args:
        src1: FunctionRef with raster tiles.
        alpha: Weight multiplied with src1.
        src2: FunctionRef with raster tile.
        beta: Weight multiplied with src2.
        gamma: Additional constant added to the result.
        blend_mode: Mode how src1 and src2 are combined. See above.

    Function Returns:
        TileData with the blended raster tile information.

    Client Returns:
        -

    """
    api_class: Literal['dfm.api.maptiling_2d.BlendRasterTiles'] =\
                        'dfm.api.maptiling_2d.BlendRasterTiles'
    src1: FunctionRef
    alpha: float = 0.5
    src2: FunctionRef
    beta: float = 0.5
    gamma: float = 0.0
    # both: src1*alpha + src2*beta + gamma. clipped between 0 and 255
    # addto_src1: src1*alpha + src2.filled(0)*beta + gamma
    # into_src1: np.copyto(src1*alpha, src2.filled(0)*beta, where=src2*beta != 0)+self.params.gamma
    blend_mode: Literal['both', 'addto_src1', 'addto_src2', 'into_src1', 'into_src2'] = 'both'
