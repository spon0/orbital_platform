# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import Literal

from .. import FunctionCall, FunctionRef

class ReadTile(FunctionCall, frozen=True):
    """
    Function to read the data of a given tile from a given map dataloader.

    Args:
        loader: FunctionRef for the map data loader.
        tile_stream: FunctionRef for the function producing a stream of tiles.
        pixelbuffer: An additional buffer around each tile in pixels, used if boundary computations
                     require an overlap. Only for raster data.
        band: The band number to read. Only for raster data. GDAL bands start at 1.

    Function Returns:
        TileData with the tile information.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.ReadTile'] =\
                        'dfm.api.maptiling_2d.ReadTile'
    loader: FunctionRef
    tile_stream: FunctionRef
    pixelbuffer: int = 0
    band: int = 1
