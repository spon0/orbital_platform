# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import Literal, Optional

from .. import FunctionCall
from ._datatypes import EpsgCrs, ProjCrs, ResamplingAlgorithm, WktCrs

class OpenRasterInput(FunctionCall, frozen=True):
    """
    Function to open an input source containing raster tile data.

    Args:
        src_file: The source filename inside the storage configured at the provider
                containing the raster data. Providers may allow clients to submit
                remote URLs in src_file, in which case the remote URL is opened.
        src_crs: The crs of the raster data. If None, the crs will be read from the
                source file. Otherwise, the src_crs is assumed to be correct.
                If the source file indicates a different crs an error is raised.
        resampling: The algorithm to use to resample when translating between different
                projections.

    Function Returns:
        A GeoInput data loader object to load tile data.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.OpenRasterInput'] =\
                        'dfm.api.maptiling_2d.OpenRasterInput'
    src_file: str
    src_crs: Optional[WktCrs | EpsgCrs | ProjCrs] = None
    resampling: ResamplingAlgorithm  = 'nearest'
