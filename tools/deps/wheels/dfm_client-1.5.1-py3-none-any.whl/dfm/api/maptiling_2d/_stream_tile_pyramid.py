# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import List, Literal, Optional
from .. import FunctionCall, FunctionRef

from ._datatypes import (
    ResamplingAlgorithm,
    TileCoords,
    PyramidGrid,
    Metatiling,
    ZoomLevels
)

class StreamTilePyramid(FunctionCall, frozen=True):
    """
    Function to stream a tile pyramid. A tile pyramid is specified by its grid and may be
    restricted to a given region. The given region can be specified explicitly in this function
    and/or be computed by union or intersection of the regions covered by the passed data loaders.

    Args:
        region_inputs: List of FunctionRefs to map data loader functions. The covered regions of
                       the passed map data loaders are either unioned or intersected to compute
                       the region from which tiles should be streamed.
        region: Explicit region to restrict the streamed tiles to. Either a string with a WKT
                polygon, a single TileCoords tile, or a list of TileCoords tiles.
        method: 'union' or 'intersection', specifying how regions and region_inputs should be
                combined to compute the region that should get streamed.
        grid: A PyramidGrid specifying the grid for this pyramid.
        batch_by: 'row' or 'column', specifying if tiles should be streamed in row-first or
                column-first order.
        metatiling: A power of 2, specifying the steepness of the pyramid. 
        tile_size: Tile size in pixels.
        zoom_levels: which zoom levels of the tile pyramid should be streamed.

    Function Returns:
        A stream of TileData objects.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.StreamTilePyramid'] =\
                        'dfm.api.maptiling_2d.StreamTilePyramid'
    region_inputs: List[FunctionRef]
    region: Optional[str | TileCoords | List[TileCoords]] = None # WKT or explicit tiles
    method: Literal['union', 'intersection'] = 'intersection' # how to combine   inputs and extent
    grid: PyramidGrid = 'mercator'
    batch_by: Optional[Literal['row', 'column']] = None
    metatiling: Metatiling = 1
    tile_size: int = 256
    zoom_levels: ZoomLevels = ZoomLevels(first=0, last=12)
