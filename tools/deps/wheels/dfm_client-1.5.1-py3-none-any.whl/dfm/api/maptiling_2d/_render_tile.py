# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import Literal, Optional
from .. import FunctionCall, FunctionRef

class RenderTile(FunctionCall, frozen=True):
    """
    Function to render a raster tile into an image. RenderTile adapters generally cache their
    outputs by tile ID such that subsequent requests for tiles that have been computed
    are answered from cache. This caching is across tiles from different tile streams as long
    as the tile computation is the same. That is, if a pipeline requests tiles 
    [(12,120,450), (12,120,451)] and a subsequent pipeline requests tiles [(12,120,451), (12,120,452)],
    the overlapping tile (12,120,451) will be served from cache as long as the functions
    computing the tile are the same in both pipelines.

    Args:
        tile_stream: FunctionRef for the function producing the tile stream.
        data: FunctionRef for the raster tile to render.
        tile_format: A supported image format.
        img_quality: If supported by an image format, a measure of quality in % (e.g. 90)
        return_image_data: If True, returns the tile image in a base64 encoded string.

    Function Returns:
        TextureFile.

    Client Returns:
        A ValueResponse with a TextureFile.
    """
    api_class: Literal['dfm.api.maptiling_2d.RenderTile'] =\
                        'dfm.api.maptiling_2d.RenderTile'
    tile_stream: FunctionRef
    data: FunctionRef
    tile_format: str = "png"
    img_quality: Optional[int] = None
    return_image_data: bool = False
