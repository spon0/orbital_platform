# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from typing import Literal, Tuple

from .. import FunctionCall, FunctionRef

class RasterizeVectorTile(FunctionCall, frozen=True):
    """
    Function to rasterize a vector tile into a raster tile. The raster tile
    shape and size in pixels is defined by the input TileData's tile information.

    Args:
        tile: FunctionRef with the vector tile as input.
        color: The rgb color used to paint and fill the vector objects.

    Function Returns:
        TileData with the rasterized tile information.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.RasterizeVectorTile'] =\
                        'dfm.api.maptiling_2d.RasterizeVectorTile'
    tile: FunctionRef
    color: int|Tuple[int, int, int]
