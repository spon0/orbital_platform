# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import List, Literal, Tuple

from pydantic import BaseModel
from .. import FunctionCall, FunctionRef

from ._datatypes import (
    Shape,
    WktCrs,
    EpsgCrs,
    ProjCrs,
)

class WktTile(BaseModel, frozen=True):
    """
    A tile expressed as Well-Known-Text (WKT).

    Args:
        wkt: The WKT with the tile polygon.
        tile_size: The size/shape of the tile in pixels.
    """
    wkt: str
    # either in pixelsize (xsize, ysize) in CRS units or the tile width/height in pixels
    tile_size: Tuple[float, float] | Shape

class StreamWktTiles(FunctionCall, frozen=True):
    """
    Function to stream a list of tiles explicitly specified as WKT.

    Args:
        region_inputs: List of FunctionRefs to map data loader functions. The covered regions of
                       the passed map data loaders are either unioned or intersected to compute
                       the region from which tiles should be streamed.
        method: 'union' or 'intersection', specifying how regions and region_inputs should be
                combined to compute the region that should get streamed.
        crs: The CRS used for the WKT tiles.
        tiles: List of WktTile objects.

    Function Returns:
        A stream of TileData objects.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.StreamWktTiles'] =\
                        'dfm.api.maptiling_2d.StreamWktTiles'
    region_inputs: List[FunctionRef]
    method: Literal['union', 'intersection'] = 'intersection' # how to combine region inputs
    crs: WktCrs|EpsgCrs|ProjCrs
    tiles: List[WktTile]
