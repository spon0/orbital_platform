# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from typing import Literal

from pydantic import BaseModel
from pyproj import CRS


ResamplingAlgorithm = Literal[
        'nearest',
        'bilinear',
        'cubic',
        'cubic_spline',
        'lanczos',
        'average',
        'mode',
        'gauss',
        'max',
        'min',
        'med',
        'q1',
        'q3',
        'sum',
        'rms'
    ]

Metatiling = Literal[1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

class WktCrs(BaseModel):
    """e.g. GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]] """
    wkt: str
    def as_crs(self)->CRS:
        return CRS.from_wkt(self.wkt)

class EpsgCrs(BaseModel):
    """e.g. {'epsg': 4326} or {'epsg': 3857}"""
    epsg: int
    def as_crs(self)->CRS:
        return CRS.from_epsg(self.epsg)

class ProjCrs(BaseModel):
    """e.g. {'proj': "+proj=utm +zone=32 +datum=WGS84 +units=m +no_defs"}"""
    proj: str 
    def as_crs(self)->CRS:
        return CRS.from_string(self.proj)

class Shape(BaseModel):
    height: int
    width: int

class Bounds(BaseModel):
    left: float
    bottom: float
    right: float
    top: float

class TileCoords(BaseModel):
    zoom: int
    row: int
    col: int
    
class ZoomLevels(BaseModel):
    first: int
    last: int

class CustomPyramidGrid(BaseModel):
    shape: Shape
    bounds: Bounds    
    crs: WktCrs | EpsgCrs | ProjCrs
    is_global: bool = False

PyramidGrid = Literal['mercator', 'geodetic'] | CustomPyramidGrid
