# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""FunctionParams for an echo, mainly for testing"""

from typing import Dict, Literal, Optional

from .. import FunctionCall
from ._datatypes import ResamplingAlgorithm

class OpenWmtsInput(FunctionCall, frozen=True):
    """
    Function to open an input source containing tile data from a WMTS (web map tile service).

    Args:
        resampling: The algorithm to use to resample when translating between different
                projections.
        url_keys: Key-value pairs that will be inserted into the provider's URL template.
        secret: If the provider's URL template requires a secret, such as an API key, this value
                gets inserted in this position.

    Function Returns:
        A GeoInput data loader object to load tile data.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.maptiling_2d.OpenWmtsInput'] =\
                        'dfm.api.maptiling_2d.OpenWmtsInput'
    resampling: ResamplingAlgorithm  = 'nearest'
    url_keys: Optional[Dict[str, str]] = None
    # TODO: at some point, use pydantic SecretStr; but SecretStr is currently not
    # being serialized, so we keep it as a str
    secret: Optional[str] = None
