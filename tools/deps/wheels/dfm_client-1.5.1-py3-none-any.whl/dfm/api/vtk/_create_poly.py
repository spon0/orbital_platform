# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import List, Literal, Tuple
from .. import FunctionCall

class CreatePoly(FunctionCall, frozen=True):
    """
    Creates a vtkPolyData object using the given vertices and faces.

    Args:
        vertices: List of 3D points specifying the verticesl
        faces: List of integer tuples specifying the faces.

    Function Returns:
        vtkPolyData

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.vtk.CreatePoly'] =\
                        'dfm.api.vtk.CreatePoly'
    vertices: List[Tuple[float, float, float]] = [ # a cube
        (0.5, 0.0, 0.0), (1.0, 0.0, 0.0), (1.0, 1.0, 0.0), (0.0, 1.0, 0.0),
         (0.0, 0.0, 1.0), (1.0, 0.0, 1.0), (1.0, 1.0, 1.0), (0.0, 1.0, 1.0)
    ]
    faces: List[Tuple[int, ...]] = [ # faces of the cube
        (0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
        (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)
    ]
