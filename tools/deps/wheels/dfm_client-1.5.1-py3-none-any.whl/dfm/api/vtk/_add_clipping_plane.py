# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal, Tuple
from .. import FunctionCall, FunctionRef

class AddClippingPlane(FunctionCall, frozen=True):
    """
    Function to add a clippling plane to a vtk mapper. 

    Args:
        mapper: FunctionRef for the vtkPolyDataMapper.
        origin: 3D origin of the clipping plane.
        normal: 3D normal of the clipping plane.

    Function Returns:
        The passed vtkPolyDataMapper but with added clipping plane.

    Client Returns:
        -

    """
    api_class: Literal['dfm.api.vtk.AddClippingPlane'] =\
                        'dfm.api.vtk.AddClippingPlane'
    mapper: FunctionRef
    origin: Tuple[float, float, float] = (0, 0, 0)
    normal: Tuple[float, float, float] = (0, 0, -1)
