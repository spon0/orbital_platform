# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal, Tuple
from .. import FunctionCall, FunctionRef

class CreateRenderer(FunctionCall, frozen=True):
    """
    Creates a vtkRenderer object given a mapper, a camera position and focal point.

    Args:
        mapper: FunctionRef with a vtkMapper object.
        camera_position: 3D point defining the camera position.
        camera_focal_point: 3D focal point.
        background_color: Default color to use for the background. One of 
                          ['White', 'Silver', 'Black', 'Cornsilk', 'Pink']

    Function Returns:
        A vtkRenderer object.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.vtk.CreateRenderer'] =\
                        'dfm.api.vtk.CreateRenderer'
    mapper: FunctionRef
    camera_position: Tuple[float, float, float] = (0, 0, 0)
    camera_focal_point: Tuple[float, float, float] = (0, 0, 0)
    background_color: Literal['White', 'Silver', 'Black', 'Cornsilk', 'Pink'] = 'Cornsilk'
