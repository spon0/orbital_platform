# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import List, Literal
from .. import FunctionCall, FunctionRef

class SetPointScalars(FunctionCall, frozen=True):
    """
    Sets scalar values in the points of a vtkPolyData.

    Args:
        poly: FunctionRef for the vtkPolyData object.
        default: Default value to use if the scalars list is less than the number of points 
                 in the poly
        scalars: List of float values, one for each point in the poly, in the same order.

    Function Returns:
        Same vtkPolyData object but with scalars set on the points.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.vtk.SetPointScalars'] =\
                        'dfm.api.vtk.SetPointScalars'
    poly: FunctionRef
    # used if scalars list is less than number of points in the poly
    default: float = 0
    scalars: List[float] = []
