# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal, Tuple
from .. import FunctionCall, FunctionRef

class RenderAsPng(FunctionCall, frozen=True):
    """
    Renders the view of a given renderer as a png.

    Args:
        renderer: FunctionRef for a vtkRenderer object.
        size: Size of the rendered image in pixels.

    Function Returns:
        An Image object with the rendered image.

    Client Returns:
        A ValueResponse with a string containing the base64 encoded image data.
    """
    api_class: Literal['dfm.api.vtk.RenderAsPng'] =\
                        'dfm.api.vtk.RenderAsPng'
    renderer: FunctionRef
    size: Tuple[int, int] = (600,600)
