# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""The base class for all Function models."""
from typing import Any, Literal
import uuid

from pydantic import UUID4, ConfigDict, Field, field_validator
from ..common import PolymorphicBaseModel, AdviseableBaseModel

class FunctionCall(PolymorphicBaseModel, AdviseableBaseModel, frozen=True):
    """
    The base class for all Function models.
    
    When implementing a new Function model, remember to:
    1. add an import to the __init__.py
    2. use FunctionRef as the data type for input fields

    FunctionCalls are PolymorphicBaseModels. That is, the json
    serialized data contains a field 'api_class' that is used to
    identify the concrete class of the data, so that the correct
    model is used for deserialization. 

    Args:
        api_class: The fully qualified name of this FunctionCall class. Must be equal to
                   the fully qualified classname of the corresponding pydantic model.
        provider: The provider for which this function should get called.
        node_id: A uuid4 uniquely identifying this node inside the pipeline.
        is_output: If True, the result of this FunctionCall should get sent back to the client.
        force_compute: If True, the result of this FunctionCall should be computed irrespective
                    of whether cached values exist or not.

    """
    model_config = ConfigDict(extra='forbid')

    api_class: Literal['ABSTRACT']
    provider: str = 'dfm'
    node_id : UUID4 = Field(default_factory=uuid.uuid4)
    is_output: bool = False
    force_compute: bool = False # if true, ignore the caches

    @classmethod
    def api_key(cls)->str:
        return cls.model_fields['api_class'].default

    @classmethod
    def set_allow_outside_block(cls, val: bool=True)->bool:
        before = hasattr(FunctionCall, '_allow_outside_block') and\
                    getattr(FunctionCall, '_allow_outside_block')
        if val:
            setattr(FunctionCall, '_allow_outside_block', val)
        else:
            delattr(FunctionCall, '_allow_outside_block')
        return before

    @classmethod
    def unset_allow_outside_block(cls)->bool:
        return cls.set_allow_outside_block(False)

    # Pydantic callback
    def model_post_init(self, __context):
        # import here to break circular dependency
        from ._block import Block # pylint: disable=import-outside-toplevel
        try:
            Block.get_block().add_to_body(self)
        except RuntimeError as e:
            if hasattr(FunctionCall, '_allow_outside_block')\
               or (
                   __context\
                   and 'allow_outside_block' in __context
                   and __context['allow_outside_block']
               ):
                return
            raise e

    @field_validator('*')
    @classmethod
    def rewrite_functioncall_to_uuid(cls, v: Any) -> Any:
        if isinstance(v, FunctionCall):
            return v.node_id
        if isinstance(v, list):
            # rewrite all FunctionCall objects to their node_id
            return [e.node_id if isinstance(e, FunctionCall) else e for e in v]
        return v

FunctionRef = FunctionCall | UUID4
