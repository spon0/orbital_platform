# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall, FunctionRef

class MonitorMove(FunctionCall, frozen=True):
    """
    Function to monitor an ongoing data move, periodically sending status
    messages back to the client's home site.

    Args:
        req_id: A FunctionRef of the RequestMove function that is monitored.
        is_output: Default is set to True.
    
    Function Returns:
        -
    
    Client Returns:
        Status messages with move status.
    """
    api_class: Literal['dfm.api.datamover.MonitorMove'] =\
                        'dfm.api.datamover.MonitorMove'
    req_id: FunctionRef
    is_output: bool = True
