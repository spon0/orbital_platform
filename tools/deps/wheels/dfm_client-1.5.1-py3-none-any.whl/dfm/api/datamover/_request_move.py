# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall, FunctionRef

class RequestMove(FunctionCall, frozen=True):
    """
    Function to request a data move. The storage locations of the source
    and target are configured in the provider, the client selects the
    files that get moved.

    Args:
        source: FunctionRef returning the path and filename inside the source location for the
                file to be moved. Often a Constant function.
        target: String for the path and filename inside the target location where the moved
                data should be stored.

    Function Returns:
        A req_id, an ID representing the request that can be passed to the other
        datamover functions.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.datamover.RequestMove'] =\
                        'dfm.api.datamover.RequestMove'
    source: FunctionRef
    target: str
