# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall, FunctionRef

class WsAccept(FunctionCall, frozen=True):
    """
    Function that accepts an incoming websocket connection.

    Args:
        uri: FunctionRef for the uri of the websocket server for which connections are accepted.
        stop_after: Counter for how many connections are accepted.
        timeout: Timeout in seconds.

    Function Returns:
        A WebSocket connection object.

    Client Returns:
        -
    """
    api_class: Literal['dfm.api.websockets.WsAccept'] =\
                        'dfm.api.websockets.WsAccept'
    provider: str ='websockets'
    uri: FunctionRef
    stop_after: int = 1
    timeout: int = 5
