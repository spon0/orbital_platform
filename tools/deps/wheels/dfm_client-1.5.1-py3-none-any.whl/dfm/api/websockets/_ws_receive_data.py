# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall, FunctionRef

class WsReceiveData(FunctionCall, frozen=True):
    """
    Function to receive data via a websocket connection. 
    WsSendData pickles the data and WsReceiveData unpickles it.

    Args:
        socket: FunctionRef for the WebSocket connection object.
        timeout: Timeout in seconds for receiving the data.
        close_afterwards: If True, the websocket connection will be closed after the data
                 was received.

    Function Returns:
        The object that was sent by WsSendData. 
    
    Client Returns:
        -
    """
    api_class: Literal['dfm.api.websockets.WsReceiveData'] =\
                        'dfm.api.websockets.WsReceiveData'
    provider: str ='websockets'
    socket: FunctionRef
    timeout: int = 10
    close_afterwards: bool = False
