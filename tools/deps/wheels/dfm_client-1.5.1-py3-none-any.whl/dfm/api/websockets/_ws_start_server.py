# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall

class WsStartServer(FunctionCall, frozen=True):
    """
    Function to start a WebSocket server.

    Args:
        -

    Function Returns:
        URI configured in the provider under which this websocket is reachable.

    Client Returns:
        ValueResponse with the websocket server URI as a string.

    """
    api_class: Literal['dfm.api.websockets.WsStartServer'] =\
                        'dfm.api.websockets.WsStartServer'
    provider: str ='websockets'
