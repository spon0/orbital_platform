# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Any, Dict, Iterator, List, Literal, Optional, Set, Tuple, Union
from pydantic import BaseModel, JsonValue

class ErrorFieldAdvice(BaseModel):
    """Represents an edge where a field advice resulted in an error."""
    msg: str

class PartialError(Exception):
    """Raised when a path ends with a partial edge."""

class PartialFieldAdvice(BaseModel):
    """An edge represents a partial field advice if the discovery has been
    cut off to avoid combinatorial explosion. When the client encounters a partial
    field advice, it should commit to values of preceding fields and then run a
    new discovery for the remainder."""
    partial: Literal['partial'] = 'partial'

EdgeT = Union['BranchFieldAdvice', 'SingleFieldAdvice', ErrorFieldAdvice, PartialFieldAdvice, None]

def edge_has_target(edge:EdgeT)->bool:
    return isinstance(edge, FieldAdvice)
def edge_get_target(edge:EdgeT)->'FieldAdvice':
    if not isinstance(edge, FieldAdvice):
        raise ValueError("Edge does not have a target")
    return edge
def edge_has_error(edge:EdgeT)->bool:
    return isinstance(edge, ErrorFieldAdvice)
def edge_get_error(edge:EdgeT)->ErrorFieldAdvice:
    if not isinstance(edge, ErrorFieldAdvice):
        raise ValueError("Edge is not an error")
    return edge
def edge_is_partial(edge:EdgeT)->bool:
    return isinstance(edge, PartialFieldAdvice)
def edge_is_good_path(edge:EdgeT)->bool:
    if isinstance(edge, ErrorFieldAdvice):
        return False
    if isinstance(edge, FieldAdvice):
        return edge.has_good_options()
    # partial and None both (may) lead to a good outcome
    return True
def edge_collect_into(edge:EdgeT, field: str, error_map: Dict[str, Set[str]]):
    def add_error(msg: str):
        if field not in error_map:
            error_map[field] = set()
        error_map[field].add(msg)
    if edge_has_error(edge):
        add_error(edge_get_error(edge).msg)
    elif edge_has_target(edge):
        edge_get_target(edge).collect_into(error_map=error_map)

class FieldAdvice(BaseModel, ABC, Iterable, frozen=True):
    """Abstract class for BranchFieldAdvice and SingleFieldAdvice."""
    @abstractmethod
    def has_good_options(self)->bool:
        pass
    @abstractmethod
    def collect_into(self, error_map: Dict[str, Set[str]]):
        pass
    @abstractmethod
    def collect_error_messages(self)->Dict[str, Set[str]]:
        pass
    @abstractmethod
    def select(self, value: JsonValue)->Optional['FieldAdvice']:
        pass
    @abstractmethod
    def __iter__(self)->Iterator[JsonValue]:
        pass

class BranchFieldAdvice(FieldAdvice, frozen=True):
    """BranchFieldAdvice is an advice for a given field which results in
    branching of the advice tree. Branches indicate that possilbe values of subsequent
    fields depend on the value selected for this field."""
    field: str
    branches: List[Tuple[JsonValue, EdgeT]]
    def has_good_options(self)->bool:
        return any(edge_is_good_path(edge) for _, edge in self.branches)
    def collect_into(self, error_map: Dict[str, Set[str]]):
        for _, edge in self.branches:
            edge_collect_into(edge, field=self.field, error_map=error_map)
    def collect_error_messages(self)->Dict[str, Set[str]]:
        error_map = {}
        self.collect_into(error_map=error_map)
        return error_map
    def select(self, value: JsonValue)->Optional['FieldAdvice']:
        it = iter(self.branches)
        val, edge = next(it)
        while val != value:
            val, edge = next(it)
        if edge_has_error(edge):
            # if you checked that there's a good option and used that value, this shouldn't happen
            raise ValueError(f"Option resulted in error {edge_get_error(edge)}")
        if edge_is_partial(edge):
            raise PartialError()
        if edge_has_target(edge):
            return edge_get_target(edge)
        return None
    def __iter__(self)->Iterator[JsonValue]:
        class ValueIterator(Iterator):
            def __init__(self, advice: BranchFieldAdvice):
                self._branches = advice.branches
                self._it = iter(advice.branches)
            def __next__(self)->Any:
                nxt_val, nxt_edge = next(self._it)
                while not edge_is_good_path(nxt_edge):
                    nxt_val, nxt_edge = next(self._it)
                return nxt_val
        return ValueIterator(self)

class SingleFieldAdvice(FieldAdvice, frozen=True):
    """An advice for a single field. The value of the field may constist of a list of
    possible values, but the subsequent advice is independent on which value is
    chosen and therefore doesn't branch out."""
    field: str
    value: JsonValue
    edge: EdgeT = None
    def has_good_options(self)->bool:
        return edge_is_good_path(self.edge)
    def collect_into(self, error_map: Dict[str, Set[str]]):
        edge_collect_into(self.edge, field=self.field, error_map=error_map)
    def collect_error_messages(self)->Dict[str, Set[str]]:
        error_map = {}
        self.collect_into(error_map=error_map)
        return error_map
    def select(self, _value: JsonValue)->Optional['FieldAdvice']:
        if edge_has_error(self.edge):
            raise ValueError(f"Option resulted in error {edge_get_error(self.edge)}")
        if edge_is_partial(self.edge):
            raise PartialError()
        if edge_has_target(self.edge):
            return edge_get_target(self.edge)
        return None
    def __iter__(self)->Iterator[JsonValue]:
        if not edge_is_good_path(self.edge):
            raise StopIteration()
        if isinstance(self.value, Iterable) and not isinstance(self.value, str):
            return iter(self.value)
        return iter([self.value])
