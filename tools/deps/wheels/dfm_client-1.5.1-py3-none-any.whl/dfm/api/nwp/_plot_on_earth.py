# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

""""""

from typing import Literal
from .. import FunctionCall, FunctionRef

class PlotOnEarth(FunctionCall, frozen=True):
    """
    Function to plot a global field, given as an xarray, as a plotted image.
    This function is mainly meant for testing to visualize the result on the globe.

    Args:
        dataset: FunctionRef for the xarray input data.
        latitude_dim: Name of the dimension for the latitude. Default 'latitude'.
        longitude_dim: Name of the dimension for the longitude. Default 'longitude'.
        variable: xarray Variable to plot.
        width_in_in: Width of the plotted image in inches.
        height_in_in: Height of the plotted image in inches.
        format: Format of the produced image.
    
    Function Returns:
        Image object.

    Client Returns:
        ValueResponse with a base64 encoded string containing the plotted image.
    """
    api_class: Literal['dfm.api.nwp.PlotOnEarth'] =\
                        'dfm.api.nwp.PlotOnEarth'
    dataset: FunctionRef
    latitude_dim: str = 'latitude'
    longitude_dim: str = 'longitude'
    variable: str
    width_in_in: float = 15
    height_in_in: float = 15
    format: Literal['png', 'jpeg'] = 'png'
